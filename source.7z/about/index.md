---
title: 关于 | About
date: 2020-12-05 12:06:52
type: "about"
---
# 基本信息
姓名:曹峻豪

性别:男

出生日期:2007年05月03日

学业经历:

    2013——2017:重庆市两江新区民心佳园小学校
    2018——2018:重庆市巴南区鱼洞第四小学校
    2019——至今:重庆市巴南实验中学校

# 联系方式
## 正文
QQ:1617537773

WeChat:sindeltacos

E-Mail:

    1617537773@qq.com
    sindeltacos@qq.com
    sindeltacoc@outlook.com
    sindeltacos@126.com
    sindeltacos@163.com
    sindeltacos@yeah.net
    sindeltacos@foxmail.com
    不常用:
    sindeltacos@gmail.com
Github:sindeltacos

Bilibili:CQDAY

其他的没了

我的联系方式都在左侧边栏设置有超链接按钮。

## 注释
没错那几个E-Mail地址全是我的2333333